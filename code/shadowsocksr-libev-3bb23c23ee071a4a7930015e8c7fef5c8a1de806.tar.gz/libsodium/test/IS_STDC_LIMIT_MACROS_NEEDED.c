#include <limits.h>
#include <stdint.h>

void main(){
	(void) SIZE_MAX;
	(void) UINT64_MAX;
}